# 8.	List Empno, Ename and Salary in the ascending order of salary.

use emp_dept;
select empno, ename, sal from emp
order by sal asc;