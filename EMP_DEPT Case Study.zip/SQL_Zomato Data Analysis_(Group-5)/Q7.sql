# List Employee Names with designations who does not report to anybody

use emp_dept;
select ename, job from emp
where job = "president"; 
 
